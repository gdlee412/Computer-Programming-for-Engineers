#include "Entry.h"

Entry::~Entry() = default;

//overload << operator here
std::ostream& operator<<(std::ostream& os, const Entry& entry)
{
  //Implement your code here
  //print a * and the name of entry
  entry.print(os, 0);
  os << std::endl;
  
  return os;
}
