#include "Directory.h"

#include <iomanip>
#include <sstream>
using namespace std;

//DO NOT MODIFY THIS START
Entry* Directory::clone() const
{
    return new Directory(*this);
}
//DO NOT MODIFY THIS END

//Implement constructor, destructor, member functions of the Directory class.

//name constructor
Directory::Directory(const string& name) : name_(name)
{
  //set default count to 0
  this->count_ = 0;
  for(int i = 0; i < (int)maxcount_; i++)
  {
    this->entries_[i] = nullptr;
  }
}

//copy constructor
Directory::Directory(const Directory& o)
{ 
  this->name_ = o.name();
  this->count_ = o.count();
  
  for(int i = 0; i < (int)maxcount_; i++)
  {
    this->entries_[i] = o.entries_[i];
  }
}

//destructor
Directory::~Directory()
{
  //for loop
  for(int i = 0; i < (int)maxcount_; i++)
  {
    //release each pointer in array
    delete[] entries_[i];
  }

  //release the class object
  delete this;
}

//getter function for name
const string& Directory::name() const
{
  return name_;
}

//print directories and files in current directory
void Directory::print(ostream& os, size_t indent) const
{
  //print indent
  for(int i = 0; i < int(indent) * 3; i++)
  {
    os << ' ';
  }
  //print current name
  os << "* " << this->name() << '\n';
  
  //for loop to print entries
  for(int i = 0; i < int(count_); i++)
  {
    //call the print functions of entries
    entries_[i]->print(os, indent + 1);
  }
}

//return content of directory
string Directory::content() const
{
  string finalcontent = "";  //string to save the names of all the contents
  
  //for loop to go through all the files / directories
  for(int i = 0; i < int(count_); i++)
  {
    //append the new entry name and a '\n' which separates the names
    finalcontent += entries_[i]->name() + '\n';
  }
  
  finalcontent += '\n';
  
  return finalcontent;
}

//getter function for count
size_t Directory::count() const
{
  return count_;
}

//find entry
Entry* Directory::find(const string& name)
{
  Entry* entry;	//temp entry object pointer for finding object
	
  //for loop to find entry with given name
  for(int i = 0; i < (int)count_; i++)	
  {
    //if entry's name is the same as name parameter
    if(entries_[i]->name() == name)
    {
      //find item then return it
      entry = entries_[i];
      return entry;
    }
  }

  //if item was not there, return empty
  return nullptr;
}

//creates a file / directory in current directory
bool Directory::add(Entry* entry)
{
  //check if file / directory with the same name exists
  for(int i = 0; i < int(count_); i++)
  {
    if(entries_[i]->name() == entry->name())
    {
      return false;
    }
  }
  
  //add entry to array
  entries_[count_] = entry;
  //increase count
  count_++;
  //return true
  return true;
}

//remove file / directory in current directory
Entry* Directory::remove(const std::string& name)
{
  Entry* entry;  //temp entry object pointer for finding object
  int i;  //iteration variable

  //for loop to find entry
  for(i = 0; i < (int)count_; i++)
  {
    //if name found in array
    if(entries_[i]->name() == name)
    {
      //set entry as the value and break
      entry = entries_[i];
      break;
    }
  }

  //use for loop to shift entries
  for(int j = i; j < int(count_) - 1; j++)
  {
    //set every variable to the one next to it
    entries_[j] = entries_[j + 1];
  }

  //set last value to nullptr
  entries_[count_] = nullptr;
  //reduce count
  count_--;

  return entry;
}
