#include "Entry.h"
#include "Directory.h"
#include "File.h"

#include <sstream>
#include <string>

//This function finds directory with the given name(2nd argument) from the given path(1st argument)
//For example below finds "world" directory from the root directory
//find_directory(&root, "world");
Entry* find_directory(Directory* root, const std::string& path)
{
  //Implement your code here.
  //istringstream to access paths
  std::istringstream iss(path);
  //saves the current directory
  Entry *directory;
  //name of next directory
  std::string path_name;
  
  //get the root
  std::getline(iss,path_name, '/');
  
  //if string's root name is the same as our root name
  if(path_name.compare(root->name()) == 0)
  {
    //set directory pointer as root
    directory = root;
  }
  //else
  else
  {
    //return null
    return nullptr;
  }
    
  //while loop
  //loops until no other path can be found
  while(std::getline(iss, path_name, '/') && directory != NULL)
  {
    //continually updates directory to the new directory
    //use find function to find the next directory
    directory = dynamic_cast<Directory*>(directory)->find(path_name);
  }
    
  //if directory ended in null
  if(directory == NULL)
  {
    //return null
    return nullptr;
  }
  //else, just return the directory
  else
  {
    return directory;
  }
}

void exec_cmd(Directory* root,std::string cmd)
{
  //*****Do NOT MODIFY START*****
  std::istringstream iss1(cmd),iss2(cmd);
  std::string token;
  std::getline(iss2,token,' ');
  std::getline(iss1,token,' ');
  //*****DO NOT MODIFY END*****
  
  //Implement your code here
  Entry *entry;  //entry pointer
  std::string entire_path, initial_path, final_path;  //entire_path -> the entire path
                                                      //initial_path -> the path except the last name
                                                      //final_path -> only the last name
  //get the entire path
  std::getline(iss2, entire_path, ' ');
  //initial path is the entire path until the last '/'
  initial_path = entire_path.substr(0, entire_path.rfind('/'));
  //final path is the last name
  final_path = entire_path.substr(entire_path.rfind('/') + 1);
  
  //mkdir command
  if(token.compare("mkdir") == 0)
  {
    //find directory until the second to the last directory
    entry = find_directory(root, initial_path);
      
    //if name was found and it is directory
    if(entry != NULL && typeid(*entry).name() == typeid(Directory).name())
    {
      //add the directory
      bool is_add_success = dynamic_cast<Directory*>(entry)->add(new Directory(final_path));
      //if adding was not a success
      if(!is_add_success)
      {
        std::cout << "directory already exists" << std::endl;
      } 
    }
    //if path itself was not found, print no such directory
    else
    {
      std::cout << "no such directory" << std::endl;
    }  
  }
  //touch command
  else if(token.compare("touch") == 0)
  {
    //check if file exists
    entry = find_directory(root, initial_path);
    
    //if directory was found
    if(entry != NULL && typeid(*entry).name() == typeid(Directory).name())
    {
      //add file
      bool is_add_success = dynamic_cast<Directory*>(entry)->add(new File(final_path));
      //if adding was not a success
      if(!is_add_success)
      {
        std::cout << "file already exists" << std::endl;
      } 
    }
    else
    {
      std::cout << "no such directory" << std::endl;
    }
  }
  //echo command
  else if(token.compare("echo") == 0)
  {
    //retrieve content
    std::string content;
    std::getline(iss2, content, '\n');
    
    entry = find_directory(root, entire_path);
    
    //if file already exists
    if(entry != NULL && typeid(*entry).name() == typeid(File).name())
    {
      //just overwrite the file
      std::cout << dynamic_cast<File*>(entry)->content(content) << std::endl;
    }
    //if it's new file
    else
    {
      //go to initial path
      entry = find_directory(root, initial_path);
      //add file using constructor
      dynamic_cast<Directory*>(entry)->add(new File(final_path, content));
    }
    
  }
  //ls command
  else if(token.compare("ls") == 0)
  {
    //find directory
    entry = find_directory(root, entire_path);
    
    //print content of directory if directory exists
    if(entry != NULL && typeid(*entry).name() == typeid(Directory).name())
    {
      std::cout << dynamic_cast<Directory*>(entry)->content();
    }
    //else
    else
    {
      //print that no such directory exists
      std::cout << "no such directory" << std::endl;
    }
  }
  //tree command
  else if(token.compare("tree") == 0)
  {    
    //find directory
    entry = find_directory(root, entire_path);
    
    //if it is directory and it exists
    if(entry != NULL && typeid(*entry).name() == typeid(Directory).name())
    {
      std::cout << *entry;
    }
    //else
    else
    {
      //print that no such directory exists
      std::cout << "no such directory" << std::endl;
    }
  }
  //cat command
  else if(token.compare("cat") == 0)
  {
    //find file
    entry = find_directory(root, entire_path);
    
    //if file was found
    if(entry != NULL && typeid(*entry).name() == typeid(File).name())
    {
      //print content
      std::cout << dynamic_cast<File*>(entry)->content() << std::endl;
    }
    //if file was not found
    else
    {
      //print error
      std::cout << "no such file" << std::endl;
    }
  }
  //mv command
  else if(token.compare("mv") == 0)
  {
    //find first entry
    entry = find_directory(root, entire_path);
    
    //retrieve destination path
    std::string dest;
    std::getline(iss2, dest, ' ');
    
    Entry* destination = find_directory(root, dest);
    
    //if either the entry or destination is empty
    if(entry == NULL || destination == NULL)
    {
      std::cout << "no such file or directory" << std::endl;
    }
    //if destination is not a directory
    else if(typeid(*destination).name() != typeid(Directory).name())
    {
      std::cout << "no such file or directory" << std::endl;
    }
    //if both paths were found
    else
    {
      //add entry to the destination
      dynamic_cast<Directory*>(destination)->add(entry);
      
      //find path to directory before the moved entry
      entry = find_directory(root, initial_path);
      
      //remove the moved entry
      dynamic_cast<Directory*>(entry)->remove(final_path);
    }
  }
  //cp command
  else if(token.compare("cp") == 0)
  {
    //find first entry
    entry = find_directory(root, entire_path);
    
    //retrieve destination path
    std::string dest;
    std::getline(iss2, dest, ' ');
    
    Entry* destination = find_directory(root, dest);
    
    //if either the entry or destination is empty
    if(entry == NULL || destination == NULL)
    {
      std::cout << "no such file or directory" << std::endl;
    }
    //if destination is not a directory
    else if(typeid(*destination).name() != typeid(Directory).name())
    {
      std::cout << "no such file or directory" << std::endl;
    }
    //if both paths were found
    else
    {
      //clone the entries to the new directory
      dynamic_cast<Directory*>(destination)->add(entry->clone());
    }
  }
  //rmdir command
  else if(token.compare("rmdir") == 0)
  {
    //find directory
    entry = find_directory(root, entire_path);
    
    //if directory exists
    if(entry != NULL && typeid(*entry).name() == typeid(Directory).name())
    {
      //go to previous directory
      entry = find_directory(root, initial_path);
      
      //remove the directory
      dynamic_cast<Directory*>(entry)->remove(final_path);
    }
    //else
    else
    {
      //print that no such directory exists
      std::cout << "no such directory" << std::endl;
    }
  }
  //rm command
  else if(token.compare("rm") == 0)
  {
    //find file
    entry = find_directory(root, entire_path);
    
    //if file was found
    if(entry != NULL && typeid(*entry).name() == typeid(File).name())
    {
      //go to previous directory
      entry = find_directory(root, initial_path);
      
      //remove the file
      dynamic_cast<Directory*>(entry)->remove(final_path);
      
    }
    //if file was not found
    else
    {
      //print error
      std::cout << "no such file" << std::endl;
    }
  }
  //quit command
  else if(token.compare("quit") == 0)
  {
    exit(0);
  }
}


int main()
{
  //*****Do NOT MODIFY START*****
    Directory root("root");
    root.add(new Directory("hello"));
    std::cout << root << std::endl; //this prints all the directories and files in root directory. (the result of tree command)

    std::string inputBuffer;
    while(1){
      std::getline(std::cin,inputBuffer);
      if(inputBuffer.compare("exit")==0) break;
      exec_cmd(&root,inputBuffer);
    }
  //*****DO NOT MODIFY END*****

}
