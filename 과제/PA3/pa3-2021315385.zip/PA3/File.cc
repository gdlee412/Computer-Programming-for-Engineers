#include "File.h"

#include <iomanip>
using namespace std;

//DO NOT MODIFY START
File::~File() = default;

Entry* File::clone() const
{
    return new File(*this);
}
//DO NOT MODIFY END

//Implement constructor, member functions in File class

//main constructor
File::File(const string& name, const string& content) : name_(name), text_(content)
{
  text_ += '\n';
}

//copy constructor
File::File(const File& o)
{
  //copy name and content
  this->name_ = o.name();
  this->text_ = o.content();
}

//getter for name
const string& File::name() const
{
  return this->name_;
}

//print function
void File::print(ostream& os, size_t indent) const
{
  //print indent
  //last indent is only 2 spaces
  for(int i = 0; i < int(indent) * 3 - 1; i++)
  {
    os << ' ';
  }
  
  //print current name
  os << "* " << this->name() << '\n';
}

//getter for content
string File::content() const
{
  return this->text_;
}

//update content
string File::content(const string& text)
{
  //function will only be used for overwriting (including empty files)
  this->text_ = text + '\n';
  return "Content updated!\n";
}
