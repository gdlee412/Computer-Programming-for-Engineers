#include <iostream>
#include <string>
#include "guess.h"

using namespace std;

int main()
{
  //write your code here
  //choice input
  int choice = -1;
  //variable to check whether string input is accurate
  int isNumber = 0;
  //initial string input
  string input;
  //result variable to receive result from guess function
  cpe::Result result;
  
  //call genRandomNum function to generate a random number.
  cpe::genRandomNum();
  //Use while loop here to start the game.
  while(true)
  {
    //do while to get a accurate integer input between 0 - 99
    //it will continue loop while choice == -1
    //if wrong input, choice will always return to -1
    do
    {
      //first getline input using string
      getline(cin, input);
    
      //for loop to check all the characters inside the string
      for(auto i:input)
      {
        //if any character is not an integer
        if(i < 48 || i > 57)
        {
          //print error, set isNumber to 0 and break from current for loop
          cout << "Enter 0 - 99\n" << endl;
          isNumber = 0;
          break;
        }
        //if the input is always integer, keep isNumber as 1
        else
        {
          isNumber = 1;
        }
      }
      //if string input was found to be a number
      if(isNumber == 1)
      {
        //retrieve integer value
        choice = stoi(input);
        //if integer value choice is outside the guess range
        if(choice < 0 || choice > 99)
        {
          //print error and reset choice value to -1
          cout << "Enter 0 - 99\n" << endl;
          choice = -1;
        }
      }
    //loop if choice input was wrong
    }while(choice == -1);
    
    //call guess function to check whether a user entered the correct target number.
    result = cpe::guess(choice);
    //output depending on the guess result
    //larger than randomnum
    if(result == cpe::Result::LARGE)
    {
      cout << "More Smaller\n" << endl;
    }
    //correct answer
    else if(result == cpe::Result::CORRECT)
    {
      //break out from loop
      cout << "You Won" << endl;
      break;
    }
    //smaller than randomnum
    else
    {
      cout << "More Larger\n" << endl;
    }
  }
  
  return 0; 
}
