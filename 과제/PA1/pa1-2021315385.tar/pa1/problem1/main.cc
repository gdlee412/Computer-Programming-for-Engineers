#include <iostream>
#include "arrayModify.h"

using namespace std;

#define MAX 10

int main(){
  //write your code here!
  int arr[10];
  int inputcount = 0;
  
  //range based for loop to receive array input
  for( auto &x : arr )
  {
    cin >> x;
    //if input is out of range
    if( x < 0 || x > 9 )
    {
      //print error and exit
      cout << "Input must be in the range 0 - 9." << endl;
      return 0;
    }
    //increase inputcount
    inputcount++;
  }
  
  //do while to clear input
  //also to make sure there are no extra inputs
  char symbol;
  do
  {
    cin.get(symbol);
    //if there was another integer input (0 - 9)
    if(symbol > 47 && symbol < 58)
    {
      //print error and exit
      cout << "Enter 10 numbers" << endl;
      return 0;
    }
  }while(symbol != '\n');
  
  //you should call arrayModify function to modify array
  arrayModify(arr, inputcount);
  //you should call printArray function to print array
  printArray(arr, inputcount);
  
  return 0;
}
