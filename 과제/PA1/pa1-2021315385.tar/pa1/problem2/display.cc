#include <iostream>
#include "display.h"

//implement this function
void cpe::customPrint(const std::string& s){
  //write your code here!
  //use cout to print string
  std::cout << s << std::endl;
}

