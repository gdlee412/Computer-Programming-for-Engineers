#include <algorithm>
#include "arabians.h"

//implement this function
std::string cpe::reverseString(const std::string& target) {
  //write your code here!
  int length = target.length();
  //use temp string to save the original string
  std::string temp = "";
  temp += target;
  
  //find the integer occurences and retrieve the numerical value
  for(int i = 0; temp[i] != '\0'; i++)
  {
    //idea is to reverse the numerical string within the main string
    //if digit is found in string
    if(temp[i] > 47 && temp[i] < 58)
    {
      //retrieve the numerical value
      int num = stoi(temp.substr(i, length - i));
      
      //convert number to string and reverse it
      std::string num_string = std::to_string(num);
      std::reverse(num_string.begin(), num_string.end());
  
      //replace original number with reversed num
      temp.erase(i, num_string.length());
      temp.insert(i, num_string);
      
      //add the number's string length to skip the possible recounting of the same number
      i += num_string.length();
    }
  }
  
  //use reverse function from algorithm library to reverse the string
  std::reverse(temp.begin(), temp.end());
  
  //use a pointer to update the new reversed string
  std::string* ptr = (std::string *)(& target);
  *ptr = temp;
  
  //return the new string
  return target;
}

