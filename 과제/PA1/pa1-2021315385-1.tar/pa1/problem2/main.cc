#include <iostream>
#include "display.h"
#include "arabians.h"

using namespace std;

int main(){
  string s;
 
  //write your code here!
  //receive user input and store it into s variable.
  getline(cin, s);
  

  //call reverseString function to reverse string
  cpe::reverseString(s);
  
  
  //call customPrint function to print string
  cpe::customPrint(s);
  return 0;
}
