#include <iostream>
#include <fstream>
#include <cstdlib>
#include "wordProcess.h"

using namespace std;

int main()
{
  string a[2500];
  string input;
  string finalanswer;
  int numofWords = 0;
  
  //Write your code here!
  //You should read file words.txt
  ifstream fin("words.txt");
  
  //if file failed to open
  if(fin.fail())
  {
    //print error and exit
    cout << "File open failed" << endl;
    exit(1);
  }
  
  //input words from text into 'a' array
  while(!fin.eof())
  {
    //get line input from the file stream and input into 'a' array
    getline(fin, a[numofWords]);
    numofWords++;
  }
  
  //subtract one to consider the extra reading due to eof
  numofWords--;
  
  //create a new array having a size of 300 (due to the getMostPairsWord function's string array parameter size)
  string newArray[300];
  string* ptr = a;
  //use for loop to save each string from 'a' array into the newArray
  for(auto& i: newArray)
  {
    i = *ptr;
    ptr++;
  }
  
  //call getMostPairsWord function to find the most pairs of consecutive double letters
  finalanswer = cpe::getMostPairsWord(newArray);
  
  cout << finalanswer << endl;
  
  fin.close();
  return 0;
}
