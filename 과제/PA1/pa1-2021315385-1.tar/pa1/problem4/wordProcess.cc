#include "wordProcess.h"

std::string cpe::getMostPairsWord(std::string words[300])
{
  //write your code here!
  std::string MostPairsWord = "";
  int maxPairCount = 0;

  //loop through the words array
  for(int i = 0; i < 300; i++)
  {
    
    int count = 0;
    int size = words[i].length();
 
    for(int j = 0; j < size - 1; j++)
    {
      if(words[i][j] == words[i][j + 1])
      {
        if(words[i][j] > 47 && words[i][j] < 58)
        {
          continue;
        }
        else
        {
          count++;
	  j++;
        }
      }
      else if(words[i][j] == words[i][j+1] + 32 || words[i][j] == words[i][j+1] - 32)
      {
        count++;
        j++;
      }
    }
    
    if(count > maxPairCount)
    {
      maxPairCount = count;
      MostPairsWord = words[i];
    }
    else if(count == maxPairCount)
    {
      if(count == 0)
      {
        continue;
      }
      else
      {
        MostPairsWord += ", ";
        MostPairsWord += words[i];
      }
    }
  }
  return MostPairsWord;
}
