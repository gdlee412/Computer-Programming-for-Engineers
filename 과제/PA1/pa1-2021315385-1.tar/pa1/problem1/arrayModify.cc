#include "arrayModify.h"
#include <iostream>

using namespace std;

//implement these functions
void printArray(int *arr, int num){
  //write your code here!
  int printarr[num];
  //range based for loop to save and print the values of arrays using its pointer
  for(auto& i : printarr)
  {
    i = *arr;
    cout << i << " ";
    arr++;
  }
  cout << endl;
}
void arrayModify(int *arr, int num){
  //write your code here!
  int ascendingarr[num];
  //for loop (including the range based for loops) to arrange in ascending order
  //save values in ascendingarr
  for(auto& i : ascendingarr)
  {
    //to save the minimum value and its index
    int min = 10, min_index;
    //for loop to find the next smallest value
    for(int j = 0; j < num; j++)
    {
      //if next array index has a smaller value
      if(*(arr + j) < min)
      {
        //replace min value and index
        min = *(arr + j);
        min_index = j;
      }
    }
    //save these values into the ascendingarr
    i = min;
    *(arr + min_index) = 10;
  }
  
  //nested for loop to move all the even numbers to the back
  //since the array is in ascending order, doing this will automatically allow the even numbers to be in descending order
  for(auto& i : ascendingarr)
  {
    for(auto j = &i + 1; j < ascendingarr + 10; j++)
    {
      //if value is even, keep swapping with j's place to bring even to the back
      if(i % 2 == 0)
      {
        int temp = i;
        i = *j;
        *j = temp;
      }
    }
  }
  
  //save the values into the original array using the addresses
  for(auto i: ascendingarr)
  {
    *(arr) = i;
    arr++;
  }
}

