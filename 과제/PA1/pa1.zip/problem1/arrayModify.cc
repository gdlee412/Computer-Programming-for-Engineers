#include "arrayModify.h"

//implement these functions
void printArray(int *arr, int num){
  //write your code here!
}
void arrayModify(int *arr, int num){
  //write your code here!
}

