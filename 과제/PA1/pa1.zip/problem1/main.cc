#include <iostream>
#include "arrayModify.h"

using namespace std;

int main(){
  //write your code here!
  //you should call arrayModify function to modify array
  //you should call printArray function to print array
  return 0;
}
