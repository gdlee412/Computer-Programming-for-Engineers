#include <iostream>
#include "wordProcess.h"

int main()
{
  std::string a[2500];
  
  //Write your code here!
  //You should read file words.txt
  //call getMostParisWord function to find the most pairs of consecutive double letters
}
