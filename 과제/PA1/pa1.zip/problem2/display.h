//DO NOT CHANGE THIS FILE!!!!!!!!!

#ifndef DISPLAY_H
#define DISPLAY_H 
#include <string>
namespace cpe{
  void customPrint(const std::string& s);
};
#endif

