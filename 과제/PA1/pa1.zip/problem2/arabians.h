//DO NOT CHANGE THIS FILE!!!!!!!!!

#ifndef ARABIANS_H
#define ARABIANS_H 
#include <string>
namespace cpe{
  std::string reverseString(const std::string& s);
};
#endif

