#include <iostream>
#include "guess.h"

int main()
{
  //write your code here
  //call genRandomNum function to generate a random number.
  //Use while loop here to start the game.
  //call guess function to check whether a user entered the correct target number.
  return 0; 
}
