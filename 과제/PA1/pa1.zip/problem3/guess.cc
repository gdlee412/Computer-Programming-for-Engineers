#include "guess.h"
#include <iostream>
using namespace std;

int randomNum = 0;

cpe::Result cpe::guess(int num) { 
  //write your code here!
  return Result::CORRECT; 
}
  //Implement genRandomNum function here
  //This generate random number and store it into randomNum variable
  //reference guess.h file for the function signature
  
