#include "wordProcess.h"

std::string cpe::getMostPairsWord(std::string words[300])
{
  //write your code here!
  std::string MostPairsWord = "";
  int maxPairCount = 0;

  //loop through the words array
  for(int i = 0; i < 300; i++)
  {
    //declare local variables
    int count = 0;
    int size = words[i].length();
 
    //for loop to look for number of pairs
    for(int j = 0; j < size - 1; j++)
    {
      //if character is the same as the next one
      if(words[i][j] == words[i][j + 1])
      {
        //make sure character is not a number
        if(words[i][j] > 47 && words[i][j] < 58)
        {
          continue;
        }
        //if it is a pair, increase pair count and skip the pair's complement character (j++)
        else
        {
          count++;
	  j++;
        }
      }
      // case for small and big lettered pairs
      else if(words[i][j] == words[i][j+1] + 32 || words[i][j] == words[i][j+1] - 32)
      {
        count++;
        j++;
      }
    }
    //if count has more pairs than max
    if(count > maxPairCount)
    {
      //update
      maxPairCount = count;
      MostPairsWord = words[i];
    }
    //if the same
    else if(count == maxPairCount)
    {
      if(count == 0)
      {
        continue;
      }
      //add to the existing
      else
      {
        MostPairsWord += ", ";
        MostPairsWord += words[i];
      }
    }
  }
  return MostPairsWord;
}
