#include <iostream>
#include <string>
#include "arrayModify.h"

using namespace std;

int main(){
  //write your code here!
  int arr[10];
  int inputcount = 0;
  char temp_symbol;

  //range based for loop to receive array input
  for( auto &x : arr )
  {
    cin >> x;
    cin.get(temp_symbol);
    //if input is out of range
    if( x < 0 || x > 9 )
    {
      //print error and exit
      cout << "Input must be in the range 0 - 9." << endl;
      exit(1);
    }
    
    //check for more inputs (also to remove the space)
    if(temp_symbol == ' ')
    {
      //increase inputcount
      inputcount++;
    }
    
    if(temp_symbol == '\n')
    {
      //increase inputcount one last time and break
      inputcount++;
      break;
    }
  }
  
  if(inputcount < 9)
  {
    //print error and exit
    cout << "Enter 10 numbers" << endl;
    exit(1);
  }
  
  //do while to clear input if not end of input
  //also to make sure there are no extra inputs
  
  if(temp_symbol != '\n')
  {
  
    char symbol;
    do
    {
      cin.get(symbol);
      //if there was another integer input (0 - 9)
      if(symbol == 32)
      {
        //print error and exit
        cout << "Enter 10 numbers" << endl;
        exit(1);
      }
    }while(symbol != '\n');
  }
  
  //you should call arrayModify function to modify array
  arrayModify(arr, inputcount);
  //you should call printArray function to print array
  printArray(arr, inputcount);
  
  return 0;
}
