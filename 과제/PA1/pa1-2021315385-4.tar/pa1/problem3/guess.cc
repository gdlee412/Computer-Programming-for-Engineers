#include "guess.h"
#include <cstdlib>
#include <ctime>

using namespace std;

int randomNum = 0;

cpe::Result cpe::guess(int num) { 
  //write your code here!
  if(num > randomNum)
  {
    return Result::LARGE;
  }
  else if(num == randomNum)
  {
    return Result::CORRECT;
  }
  else
  {
    return Result::SMALL;
  }
}
  //Implement genRandomNum function here
  //This generate random number and store it into randomNum variable
  //reference guess.h file for the function signature
 void cpe::genRandomNum() {
   srand(time(nullptr));
   randomNum = rand() % 100;
 }
  
