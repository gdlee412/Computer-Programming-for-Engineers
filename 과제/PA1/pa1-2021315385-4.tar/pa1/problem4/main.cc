#include <iostream>
#include <fstream>
#include "wordProcess.h"

using namespace std;

int main()
{
  string a[2500];
  string finalanswer = "";
  int mostpairs = 0;
  
  //Write your code here!
  //You should read file words.txt
  ifstream fin("words.txt");
 
  //if file failed to open
  if(fin.fail())
  {
    //print error and exit
    cout << "File open failed" << endl;
    exit(1);
  }
  
  int iteration = 0;
  int numofWords = 0;
  //input words from text into 'a' array
  while(!fin.eof())
  {
    //get line input from the file stream and input into 'a' array
    getline(fin, a[numofWords]);
    if(numofWords == 2499)
    {
      break;
    }
    //if 300 words have passed
    if((numofWords + 1) % 300 == 0)
    {
      //declare variables
      string arr[300];
      int j = 0;
      //for loop to update the temporary arr
      for(auto&i : arr)
      {
        i = a[iteration * 300 + j];
        j++;
      }
      iteration++;
      
      string temp = "";
      int tempmostpairs = 0;
      //function call
      temp = cpe::getMostPairsWord(arr);
      //for loop to find number of pairs, same code concept as wordProcess.cc
      //since all the words have the same number of pairs in temp, for loop through the first word
      for(int k = 0; k != '\n'; k++)
      {
        //if it is a pair
        if(temp[k] == temp[k + 1])
        {
          //skip if number
          if(temp[k] > 47 && temp[k] < 58)
          {
            continue;
          }
          //increase pair count if it is not number
          else
          {
            tempmostpairs++;
	    k++;
          }
        }
        //for small and big letter pair case
        else if(temp[k + 1] == temp[k] + 32 || temp[k] == temp[k + 1] - 32)
        {
          tempmostpairs++;
          k++;
        }
        //once the first word is done, break out of loop
        if(temp[k] == '\n')
        {
          break;
        }
      }
      //if current temp has the same number of pairs
      if(mostpairs == tempmostpairs)
      {
        //append to string
        finalanswer += ", ";
        finalanswer += temp;
      }
      //if there's a bigger mostpairs
      else if(mostpairs < tempmostpairs)
      {
        //update mostpairs and final answer
        mostpairs = tempmostpairs;
        finalanswer = temp;
      }
    }
    numofWords++;
  }
  
  //declare variables for the last set of words
  //laststringsize = remaining words in text
  int laststringsize = numofWords - (300 * iteration) + 1;
  string arr[300];
  int j = 0;
  string temp = "";
  int tempmostpairs = 0;
  //for loop to update the temporary arr
  for(int i = 0; i < laststringsize; i++)
  {
    arr[i] = a[iteration * 300 + j];
    j++;
  }
  //function call
  temp = cpe::getMostPairsWord(arr);
  //for loop to find number of pairs, same code concept as wordProcess.cc
  //since all the words have the same number of pairs in temp, for loop through the first word
  for(int k = 0; k != '\n'; k++)
    {
      //if it is a pair
      if(temp[k] == temp[k + 1])
      {
        //skip if number
        if(temp[k] > 47 && temp[k] < 58)
        {
          continue;
        }
        //increase pair count if it is not number
        else
        {
          tempmostpairs++;
	  k++;
        }
      }
      //for small and big letter pair case
      else if(temp[k + 1] == temp[k] + 32 || temp[k] == temp[k + 1] - 32)
      {
        tempmostpairs++;
        k++;
      }
      //once the first word is done, break out of loop
      if(temp[k] == '\n')
      {
        break;
      }
    }
    //if current temp has the same number of pairs
    if(mostpairs == tempmostpairs)
    {
      finalanswer += temp;
    }
    //if there's a bigger mostpairs
    else if(mostpairs < tempmostpairs)
    {
      //update mostpairs and final answer
      mostpairs = tempmostpairs;
      finalanswer = temp;
    }
  
  //print final answer
  cout << finalanswer << endl;
  
  fin.close();
  return 0;
}
