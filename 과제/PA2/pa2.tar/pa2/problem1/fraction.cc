#include "fraction.h"
#include <iostream>
#include <string>

using namespace std;

//Implement Member Functions
