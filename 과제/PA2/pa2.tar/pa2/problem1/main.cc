#include <iostream>
#include <string>
#include "fraction.h"

using namespace std;

int main(){
  //write your code here
  return 0;
}
