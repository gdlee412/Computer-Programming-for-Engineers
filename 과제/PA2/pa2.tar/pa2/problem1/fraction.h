#ifndef FRACTION_H
#define FRACTION_H

class Fraction{
  //Write class definition here
};

#endif
