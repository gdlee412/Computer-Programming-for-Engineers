#include "calculator.h"
#include <iostream>

using namespace std;

//Implement Member Functions
