#ifndef CALCULATOR_H
#define CALCULATOR_H

class Calculator{
  //Write class definition here
};

#endif
