#include "calculator.h"
#include <iostream>
#include <stdlib.h>
#include <cmath>
#include <iomanip>

using namespace std;

//Implement Member Functions

//default constructor
Calculator::Calculator() : x(0), y(0), z(0){}

//interpret given string equation
void Calculator::interpretEquation(string equation, char operatorSign, int decimal)
{
  //temp substrings
  string val1String, val2String;
  //float values
  float val1, val2;
  //result variable
  float result;
  //variable to keep track of which string is a variable
  //1: val1, 2: val2, 3: val1 & val2
  int isVariable = 0;
  
  //first substring until the operatorSign
  val1String = equation.substr(0, equation.find(operatorSign));
  //check if string is variable
  if(val1String.find_first_of("xyz") < val1String.length())
  {
    //set string into the variable (to eliminate spaces)
    val1String = val1String[val1String.find_first_of("xyz")];
    //increment isVariable
    isVariable++;
  }
  //else, save numerical value
  else
  {
    val1 = stof(val1String);
  }
  
  //if operator sign exists, create second substring
  if(operatorSign != 0)
  {
    //second substring starts from 1 index after operatorSign
    val2String = equation.substr((equation.find(operatorSign) + 1));
    //check for variable in second string
    if(val2String.find_first_of("xyz") < val2String.length())
    {
      //set string into the variable (to eliminate spaces)
      val2String = val2String[val2String.find_first_of("xyz")];
      //increment isVariable by 2
      isVariable += 2;
    }
    //else, save numerical value
    else
    {
      val2 = stof(val2String);
    }
  }
  //if there was no operator sign, just print value
  else
  {
    //if given was a variable, set val1 to variable
    if(isVariable == 1)
    {
      val1 = retrieveVariable(val1String);
    }

    //print and return
    print(val1, decimal);
    return;
  }
  
  //before going to operators, check variable case for value conversion
  switch(isVariable)
  {
    //only first parameter is a variable
    case 1:
      //call retrieveVariable
      val1 = retrieveVariable(val1String);
      break;
    //only second parameter is a variable
    case 2:
      //call retrieveVariable
      val2 = retrieveVariable(val2String);
      break;
    //both are variables
    case 3:
      //call retrieveVariable on both variables
      val1 = retrieveVariable(val1String);
      val2 = retrieveVariable(val2String);
      break;
    //ignore if default
    default:
      break;
  }
  
  //switch case for other operators
  switch(operatorSign)
  {
    //add case
    case '+':
      //call add function
      result = add(val1, val2);
      break;
    //subtract case
    case '-':
      //call subtract function
      result = subtract(val1, val2);
      break;     
    //multiply case
    case '*':
      //call multiply function
      result = multiply(val1, val2);
      break;      
    //divide case
    case '/':
      //if divisor is 0 (val2)
      if(val2 == 0)
      {
        //print error and exit
        cout << "Operation disallowed" << endl;
        exit(1);
      }
      //call divide function
      result = divide(val1, val2);
      break;   
    //remainder case
    case '%':
      //if divisor is 0 (val2)
      if(val2 == 0)
      {
        //print error and exit
        cout << "Operation disallowed" << endl;
        exit(1);
      }
      //call remainder function
      result = remainder(val1, val2);
      //set decimal for this as 0, since only integers
      decimal = 0;
      break;  
    //power case
    case '^':
      //call power function
      result = power(val1, val2);
      decimal *= 3;
      break;  
    //equate case
    case '=':
      //if x is variable
      if(val1String == "x")
      {
        //set x to val2
        this->x = val2;
      }
      //if y is variable
      else if(val1String == "y")
      {
        //set y to val2
        this->y = val2;
      }
      //if z is variable
      else if(val1String == "z")
      {
        //set z to val2
        this->z = val2;
      }
      break;
  }

  //print result if operatorSign is not '='
  if(operatorSign != '=')
  {
    print(result, decimal);
  }

}

//retrieves variable's value
float Calculator::retrieveVariable(string variable)
{
  //if x
  if(variable == "x")
  {
    //return x
    return this->x;
  }
  //if y
  else if(variable == "y")
  {
    //return y
    return this->y;
  }
  //if z
  else if(variable == "z")
  {
    //return z
    return this->z;
  }
  
  
  return -1;
}

//add values
float Calculator::add(float x, float y)
{
  //return sum
  return x + y;
}

//subtract values
float Calculator::subtract(float x, float y)
{
  //return difference
  return x - y;
}

//multiply values
float Calculator::multiply(float x, float y)
{
  //return product
  return x * y;
}

//divide values
float Calculator::divide(float x, float y)
{
  //return quotient
  return x / y;
}

//get remainder
float Calculator::remainder(int x, int y)
{
  //return remainder
  return x % y;
}

//get the power
float Calculator::power(float x, int y)
{
  //return result of power function
  return pow(x, y);
}

//print value
void Calculator::print(float result, int decimal)
{
  //set precision using decimal and print answer
  cout.setf(ios::fixed);
  cout << setprecision(decimal) << "Answer: " << result << endl;
  
}
