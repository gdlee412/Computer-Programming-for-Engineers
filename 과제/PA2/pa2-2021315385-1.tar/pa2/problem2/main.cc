#include <iostream>
#include "calculator.h"

using namespace std;

int main(){
  //write your code here
  string equation; //string to receive equation input
  Calculator calc; //initialize calculator object
  char operatorSign; //stores local operator sign
  int variableCount = 0; //variable Count: checks number of variables
  int tempDecimal = 0, maxDecimal = 0; //temp and final for number of decimal places
  int decimalFlag = 0; //flag to tell whether a decimal was found

  //continuous while loop
  while(true)
  {
    //reinitialize variables
    operatorSign = 0;
    if(variableCount == 0)
    {
      maxDecimal = 0;
    }
    decimalFlag = 0;
    tempDecimal = 0;
    variableCount = 0;

    //receive equation input using getline
    cout << "Enter your equation to calculate: ";
    getline(cin, equation);
    
    //if "quit" was inputted
    if(equation == "quit")
    {
      //break from while loop
      break;
    }
    
    //for loop to find the operator (only one exists in the problem)
    int i;
    for(i = 0; i < (int)equation.length(); i++)
    {
      //switch case to determine the operators
      switch(equation[i])
      {
        //if current index contains any of the operators
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
        case '^':
        case '=':
          //if operator already existed
          if(operatorSign != 0)
          {
            cout << "Answer: Invalid input" << endl;
            return 0;
          }
          
          //if index is first or last
          if(i == 0 || i == (int)equation.length() - 1)
          {
            cout << "Answer: Invalid input" << endl;
            return 0;
          }
          //set operatorSign to that operator
          operatorSign = equation[i];
          //reset decimal flag
          decimalFlag = 0;
          
          //set maxDecimal to tempDecimal and reinitialize temp
          maxDecimal = tempDecimal;
          tempDecimal = 0;
          
          //break out of switch case
          break;
        //case for decimal point
        case '.':
          //increase decimal flag
          decimalFlag = 1;
          break;   
        //not an operator
        default:
          //if input is number
          if(equation[i] >= '0' && equation[i] <= '9')
          {       
            //if decimal flag is one, start adding temp
            if(decimalFlag == 1)
            {
              tempDecimal++;
            }
            
            //break
            break;
          }
          //if input is x y z
          else if(equation[i] >= 'x' && equation[i] <= 'z')
          {
            //increment variable count
            variableCount++;
            //add once more if after operatorSign(to differentiate faster)
            if(operatorSign != 0)
            {
              variableCount++;
            }
            
            //if variableCount == 2 but still before operatorsign
            if(variableCount == 2 && operatorSign == 0)
            {
              //print error and exit
              cout << "Answer: Invalid input" << endl;
              return 0;
            }
            //if variable count more than 4
            if(variableCount >= 4)
            {
              //print error and exit
              cout << "Answer: Invalid input" << endl;
              return 0;
            }
            
            //break
            break;
          }
          //if input is a space
          else if(equation[i] == ' ')
          {
            //just break
            break;
          }
          //else
          else
          {
            //print error and exit program
            cout << "Answer: Invalid input" << endl;
            return 0;
          }
      }
    }
    
    //check again for decimal places
    if(tempDecimal > maxDecimal)
    {
      maxDecimal = tempDecimal;
    }

    //call interpretEquation function
    calc.interpretEquation(equation, operatorSign, maxDecimal);
    
  }
  
  return 0;
}
