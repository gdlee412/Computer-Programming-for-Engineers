#ifndef CALCULATOR_H
#define CALCULATOR_H
#include <string>

class Calculator{
  //Write class definition here
  private:
    float x;
    float y;
    float z;
  public:
    Calculator();
    void interpretEquation(std::string equation, char operatorSign, int decimal);
    float retrieveVariable(std::string variable);
    float add(float x, float y);
    float subtract(float x, float y);
    float multiply(float x, float y);
    float divide(float x, float y);
    float remainder(int x, int y);
    float power(float x, int y);
    void print(float result, int decimal);
};

#endif
