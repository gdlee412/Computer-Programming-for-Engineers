#ifndef FRACTION_H
#define FRACTION_H
#include <string>

class Fraction{
  private:
    int N;
    int NU;
    int D;
  public:
    Fraction();
    Fraction(std::string str);
    Fraction(double b);
    Fraction sum(Fraction b);
    Fraction sum(double b);
    Fraction multiply(Fraction b);
    Fraction multiply(double b);
    void abbreviation();
    bool toMixedNum();
    void print();
    double toDouble();
    Fraction str2Fraction(std::string str);
    Fraction double2Fraction(double val);
};

#endif
