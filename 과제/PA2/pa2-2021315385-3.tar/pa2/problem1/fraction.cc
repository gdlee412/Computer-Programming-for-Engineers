#include "fraction.h"
#include <iostream>
#include <string>

using namespace std;

//Implement Member Functions

//default constructor
Fraction::Fraction(): N(0), NU(0), D(0){}

//constructor with string input
Fraction::Fraction(string str){
  
  //convert str to fraction and save into temp
  Fraction temp = str2Fraction(str);
  
  //save temp values to the current object
  this->N = temp.N;
  this->NU = temp.NU;
  this->D = temp.D;
}

//constructor with double input
Fraction::Fraction(double b){
  
  //convert double to fraction and save into temp
  Fraction temp = double2Fraction(b);
  
  //save temp values to the current object
  this->N = temp.N;
  this->NU = temp.NU;
  this->D = temp.D;
}

//add fraction and fraction
Fraction Fraction::sum(Fraction b)
{
  //sum object
  Fraction sum;
  
  //get sum
  //if either one is a whole number
  //take one whole number and set fraction as 1/1
  if(this->D == 0 && this->N != 0)
  {
    this->N -= 1;
    this->NU = 1;
    this->D = 1;
  }
  //if this value is 0, just return b
  else if(this->D == 0 && this->N == 0)
  {
    return b;
  }
  
  //if whole number, change one to 1/1
  if(b.D == 0 && b.N != 0)
  {
    b.N -= 1;
    b.NU = 1;
    b.D = 1;
  }
  //if b is 0, just return this after saving into temp
  else if(b.D == 0 && b.N == 0)
  {
    Fraction temp;
    temp.N = this->N;
    temp.NU = this->NU;
    temp.D = this->D;
    return temp;
  }
  
  //N = frac.N + frac2.N
  //NU = frac.NU * frac2.D + frac2.NU * frac.D
  //D = frac.D * frac2.D
  sum.N = this->N + b.N;
  sum.NU = this->NU * b.D + b.NU * this->D;
  sum.D = this->D * b.D;
  
  //abbreviate product object
  sum.abbreviation();
  
  //make to mixed number
  if(sum.toMixedNum())
  {
    return sum;
  }
  return sum;
}

//add fraction and double
Fraction Fraction::sum(double b)
{
  //change double to fraction and save to dblFrac
  Fraction dblFrac(b);
  //sum object
  Fraction sum;
  
  //temporarily save this variables to sum
  sum.N = this->N;
  sum.NU = this->NU;
  sum.D = this->D;
  
  //call sum and save to sum variable
  sum = sum.sum(dblFrac);
  
  //abbreviate product object
  sum.abbreviation();
  
  //make to mixed number
  if(sum.toMixedNum())
  {
    return sum;
  }
  return sum;
}

//multiply fraction and fraction
Fraction Fraction::multiply(Fraction b)
{
  //product object
  Fraction product;
  
  //if either one is a whole number
  //take one whole number and set fraction as 1/1
  if(this->D == 0 && this->N != 0)
  {
    this->N -= 1;
    this->NU = 1;
    this->D = 1;
  }
  //if this value is 0, just return 0
  else if(this->D == 0 && this->N == 0)
  {
    Fraction temp(0);
    return temp;
  }
  
  //if b is whole number, change one number to 1/1
  if(b.D == 0 && b.N != 0)
  {
    b.N -= 1;
    b.NU = 1;
    b.D = 1;
  }
  //if this value is 0, just return 0
  else if(b.D == 0 && b.N == 0)
  {
    Fraction temp(0);
    return temp;
  }
  
  
  //change both back to improper for easy multiplication
  if(this->N > 0)
  {
    //add the value to NU and set N to 0
    this->NU += this->N * this->D;
    this->N = 0;
  }
  
  if(b.N > 0)
  {
    //add the value to NU and set N to 0
    b.NU += b.N * b.D;
    b.N = 0;
  }
  
  //get the product
  product.NU = this->NU * b.NU;
  product.D = this->D * b.D;
  
  //abbreviate product object
  product.abbreviation();
  
  //make to mixed number
  if(product.toMixedNum())
  {
    return product;
  }
  return product;
}

//multiply fraction and double
Fraction Fraction::multiply(double b)
{
  //change double to fraction and save to dblFrac
  Fraction dblFrac(b);
  //product object
  Fraction product;
  
  //save current variables to product
  product.N = this->N;
  product.NU = this->NU;
  product.D = this->D;
  
  //multiply 2 products and save to product object
  product = product.multiply(dblFrac);
  
  //abbreviate product object
  product.abbreviation();
  
  //make to mixed number
  if(product.toMixedNum())
  {
    return product;
  }
  return product;
}

//abbreviates fractions
void Fraction::abbreviation()
{
  //for loop from 1 to NU to see if NU and D have common divisors
  //chose NU since NU will always be smaller using the toMixedNum function
  int i;
  for(i = 2; i <= this->NU; i++) 
  {
    //if common divisor found
    if(this->D % i == 0 && this->NU % i == 0)
    {
      //divide both sides
      this->D /= i;
      //doing this also updates the condition of for loop
      this->NU /= i;
      //reset i, set to 1 due to the i++
      i = 1;
    }
  }
}

//change to mixed number, true if changed to mixed number, and false if not
bool Fraction::toMixedNum()
{
  //if numerator is bigger or equal
  if(this->NU >= this->D)
  {
    //add the additional whole numbers
    this->N += this->NU / this->D;
    //subtract the added value from the fraction
    this->NU = this->NU - this->D * (this->NU / this->D);
    
    //if NU becomes 0, it means it was a whole number, so set NU and D to 0
    if(this->NU == 0)
    {
      this->NU = 0;
      this->D = 0;
    }
    //return true if it was improper
    return true;
  }
  
  if(this-> NU == 0)
  {
    this->D = 0;
  }
  
  //return false if not
  return false;
}

//print fraction with format
void Fraction::print()
{
  cout << this->N << " and " << this->NU << "/" << this->D << endl;
}

//convert fraction into double
double Fraction::toDouble()
{
  //initialize double value
  double val = 0;
  
  //just add whole number
  val += this->N;
  
  //if denominator is 0, only case is when it is whole number, so return
  if(this->D == 0)
  {
    return val;
  }
  
  //now just cast the fraction portion into double and add
  val += (double) this->NU / (double) this->D;
  
  return val;
}

//convert string into a Fraction
Fraction Fraction::str2Fraction(string str)
{
  //temp fraction object
  Fraction temp;
  //substring to retrieve each variable
  string substr;
  
  
  //retrieve first value 'N' through stoi
  temp.N = stoi(str);
  
  //substr starts right after first '/'
  substr = str.substr(str.find('/') + 1);
  
  //second value 'NU' is taken from the substring
  temp.NU = stoi(substr);
  
  //new substr starts after the next '/'
  substr = substr.substr(substr.find('/') + 1);
  
  //D value now taken from stoi
  temp.D = stoi(substr);

  //abbreviate the fraction
  temp.abbreviation();
  
  //check convert to mixed number
  if(temp.toMixedNum())
  {
    return temp;
  }
  return temp;
}


//convert double value into a Fraction class
Fraction Fraction::double2Fraction(double val)
{
  //temp fraction object
  Fraction temp;

  //N will be the integer position in the double
  //so mod 1 will retrieve this value
  temp.N = (int)val % 1;
  
  //since maximum number of digits is 6, multiply by 1,000,000 and abbreviate
  temp.NU = (val - temp.N) * 1000000;
  temp.D = 1000000;
  
  //abbreviate the fraction
  temp.abbreviation();
  
  //check convert to mixed number
  if(temp.toMixedNum())
  {
    return temp;
  }
  return temp;
}
