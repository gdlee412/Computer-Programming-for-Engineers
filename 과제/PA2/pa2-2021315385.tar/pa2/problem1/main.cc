#include <iostream>
#include <string>
#include "fraction.h"

using namespace std;

int main(){
  //string and double variable declaration
  string str;
  double d2;
  //positions of '/' for format checking
  int pos1, pos2;
  //counts number of '/' present in string
  int formatCounter = 0;
  //iteration variable
  int i;
  //string variable to check denominator value
  string denomStr;
  
  //make 6 decimal size
  cout.setf(ios::fixed);
  cout.setf(ios::showpoint);
  cout.precision(6);
  
  //use cin for inputs
  cin >> str >> d2;
  
  //make sure inputs are correct
  if(!cin)
  {
    //print incorrect input and exit program
    cout << "Incorrect Input" << endl;
    return 0;
  }
  
  //for loop to make sure str has 2 '/' and that they are in the right format
  for(i = 0; i < (int)str.length(); i++)
  {
    //if case for the / format
    if(str[i] == '/')
    {
      // the / is the first or last character
      if(i == 0 || i == (int)str.length() - 1)
      {
        break;
      }
      //if the second / is right beside the first one
      if(formatCounter == 1 && i == pos1 + 1)
      {
        break;
      }
      //if it is first /, add i to pos1, else pos2
      if(formatCounter == 0)
      {
        pos1 = i;
      }
      else if(formatCounter == 1)
      {
        pos2 = i;
      }
      //if more than 2 /'s, break out
      else
      {
        break;
      }
      
      //increment formatCounter
      formatCounter++;
    }
    //else, everything must be numbers
    else
    {
      if(str[i] < '0' || str[i] > '9')
      {
        break;
      }
    }
  }
  
  //if broke out of for loop
  if(i != (int)str.length())
  {
    //print error and exit
    cout << "Incorrect Input" << endl;
    return 0;
  }
  
  //denomStr is a substring containing only the denominator
  denomStr = str.substr(pos2 + 1);
  
  //if denominator is 0
  if(stoi(denomStr) == 0)
  {
    //print error and exit
    cout << "Incorrect Input" << endl;
    return 0;
  }
  
  //call constructors for frac1 and 2
  Fraction frac1(str);
  Fraction frac2(d2);
  
  //print frac1 and frac2
  frac1.print();
  frac2.print();
  
  //do the addition functions and print directly
  frac1.sum(frac1).print();
  frac1.sum(d2).print();
  
  //do the multiplication functions and print directly
  frac2.multiply(frac1).print();
  frac2.multiply(d2).print();
  
  //print the double values directly
  cout << frac1.toDouble() << endl;
  cout << frac2.toDouble() << endl;
  
  return 0;
}
