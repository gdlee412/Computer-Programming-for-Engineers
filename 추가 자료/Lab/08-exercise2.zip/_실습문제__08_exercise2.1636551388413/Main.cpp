#include <iostream>
#include <string>
using namespace std;

class Player{
private:
    string name;
public:
    Player(string myname):name(myname){}
    string getname() const {
        return name;
    }
    virtual ~Player(){
        cout<<"~Player()"<<endl;
    }
    virtual void showinfo() const=0;
    virtual int getpay() const=0;
};
class MainPlayer : public Player{
private:
	int salary;
public:
	MainPlayer(string n, int s):Player(n),salary(s){}
	int getpay() const {	return salary;	}
	void showinfo() const {	cout << getname() << "'s salary: " << getpay() << endl;	}
	~MainPlayer(){	cout << "~MainPlayer()\n";	}
};

class SubPlayer : public Player{
private:
	int matches;
	int pay_per_match;
public:
	SubPlayer(string n, int m, int p):	Player(n),matches(m),pay_per_match(p){}
	int getpay() const {	return matches*pay_per_match;	}
	void addmatch(int n){	matches += n;	}
	void showinfo() const {	cout << getname() << "'s salary: " << getpay() << endl;	}
	~SubPlayer(){	cout << "~SubPlayer()\n";	}
};

class StarPlayer: public MainPlayer{
private:
	int matches;
	int pay_per_match;
public:
	StarPlayer(string n,int s,int m,int p):
	MainPlayer(n,s),matches(m),pay_per_match(p){}
	void addmatch(int n){	matches += n;	}
	int getpay() const {	return MainPlayer::getpay()+matches*pay_per_match;	}
	void showinfo() const {	cout << getname() << "'s salary: " << getpay() << endl;	}
	~StarPlayer(){	cout << "~StarPlayer()\n";	}
};

class PlayerList{
private:
	Player* list[5];
public:
	int cnt = 0;
	void addplayer(Player *p){
		list[cnt] = p;
		cnt++;
	}
	void showinfo(){
		for(int i=0; i<cnt; i++)
			cout << list[i]->getname() << "'s salary: "<< list[i]->getpay() << endl;
	}
	void showtotal(){
		int total = 0;
		for(int i=0; i<cnt; i++)
			total += list[i]->getpay();
		cout << "Total Salary: " << total << endl;
		for(int i=0; i<cnt; i++)
			delete list[i];
	}
	~PlayerList()	{	cout << "~PlayerList";	}
};
int main(){
    PlayerList players;
    players.addplayer(new MainPlayer("태훈",200));

    SubPlayer* b = new SubPlayer("충원",15,5);
    b->addmatch(5);
    players.addplayer(b);

    StarPlayer* c = new StarPlayer("두영",500,30,10);
    c->addmatch(10);
    players.addplayer(c);

    players.addplayer(new MainPlayer("준희",300));

    players.showinfo();
    players.showtotal();

    return 0;
}