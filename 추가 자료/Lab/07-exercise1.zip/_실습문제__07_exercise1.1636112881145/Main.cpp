#include <iostream>
#include <string>
using namespace std;
class Person{
private:
    string name;
    int age;
public:
    Person(string myname,int myage): 
    name(myname), age(myage){} 
    void PrintInfo(){
        cout << "Hi, I'm " << name << " and " 
        << age << " years old." << endl;
    }
    string getname() const {return name;}
    int getage() const {return age;}
    void changename(string newname){
        name = newname;
    }
    void changeage(int newage){
        age = newage;
    }
};
class Student : public Person{
private:    
    string major1;
public:
    Student(string myname,int myage,string mymajor): 
    Person(myname,myage), major1(mymajor){}
    void PrintInfo(){
        cout << "Hi, I'm " << getname() << "(" << getage() 
        << ")" << " and my major is " << major1 << endl;
    }
    string getmajor() const {return major1;}
    void changemajor(string newmajor){
        major1 = newmajor;
    }
};
class BestStudent : public Student{
	private:
		int score;
	public:
		BestStudent(string myname, int myage, string mymajor, int myscore):
		Student(myname, myage, mymajor), score(myscore){}
		void PrintInfo(){
			cout << "Hi, I'm " << getname() << "(" << getage() << ", " << getmajor() << ") and my score is " << score << endl;
		}
};
int main(){
    BestStudent A("Taehun",26,"AI",95);

    A.PrintInfo();

    return 0;
};