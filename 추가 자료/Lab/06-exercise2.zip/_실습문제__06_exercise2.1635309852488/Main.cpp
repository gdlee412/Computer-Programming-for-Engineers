#include <iostream>
#include <string>
using namespace std;

class Person{
private:
	string name;
	int* age = new int;
	bool adult;
public:
	Person(string name, int age);
	Person(const Person& other);
    ~Person();
	void setName(string n);
	string getName();
	void setAge(int a);
	bool isAdult();
};
Person::Person(string name, int age){
	name = name;	age = age;	adult = true;
}
Person::Person(const Person& other){
	this->name = other.name;
	*(this->age) = *(other.age);
	this->adult = other.adult;
	cout << "call copy constructor" << endl;
}
Person::~Person(){
	delete age;
	cout << "call destructor" << endl;
}

void Person::setName(string n){
	this->name = n;
}
string Person::getName(){	return name; }
void Person::setAge(int a){
	*(this->age) = a;
}
bool Person::isAdult(){
	if(adult == true)	return true;
	else	return false;
}
int main()
{
	Person Taehun("taehun",26);
	Person Clone = Taehun;
    
	Clone.setName("dooyoung");
	Clone.setAge(24);
	
	string result = Clone.isAdult() ? "adult" : "kid"; 
	cout<<Clone.getName()<<" is "<<result<<endl;
	return 0;
}