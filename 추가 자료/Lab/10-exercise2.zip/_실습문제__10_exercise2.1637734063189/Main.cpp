#include <iostream>
using namespace std;
class Time{
private:
	int hour, minute, second;
public:
	void seth(int h) {	this->hour = h;	}
	void setm(int m) {	this->minute = m;	}
	void sets(int s) {	this->second = s;	}
	friend istream& operator>>(istream& is, Time& t);
	friend ostream& operator<<(ostream& os, const Time& t);
	friend const Time operator+(const Time &t1, const Time &t2);
	const Time operator++(int){
		Time t;
		t.seth(hour++);	t.setm(minute++);	t.sets(second++);
		return t;
	}
};
istream& operator>>(istream& is, Time& t){
	is >> t.hour >> t.minute >> t.second;
	return is;
}
ostream& operator<<(ostream& os, const Time& t){
	int h, m, s, sum = 0;
	sum = 3600*(t.hour) + 60*(t.minute) + (t.second);
	h = sum/3600;	m = (sum%3600)/60;	s = (sum%3600)%60;
	if(h > 23)	h = h-24;
	Time newt;	newt.seth(h);	newt.setm(m);	newt.sets(s);
	os << newt.hour << "h " << newt.minute << "m " << newt.second << "s";
	return os;
}
const Time operator+(const Time &t1, const Time &t2){
	Time newt;
	newt.seth(t1.hour+t2.hour);	newt.setm(t1.minute+t2.minute);	newt.sets(t1.second+t2.second);
	return newt;
}
int main(){
    Time t1;
    Time t2;
    cin >> t1 >> t2;
    Time t3 = t1+t2;

    cout << t1 << endl;
    cout << t2 << endl;
    cout << t3++ << endl;
    cout << t3 << endl;
    return 0;
}