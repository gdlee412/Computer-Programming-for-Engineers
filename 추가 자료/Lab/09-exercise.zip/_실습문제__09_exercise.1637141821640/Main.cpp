#include <iostream>
#include <string>
using namespace std;
class Animal{
protected:
    string name;
public:
    Animal(string myname):name(myname){}
    virtual ~Animal(){}
    virtual void sound() const=0;
    virtual void info() const=0;
};
class Dog : public Animal {
private:
	string color;
public:
	Dog(string n, string c):Animal(n), color(c){}
	~Dog(){	cout << "~Dog()\n";	}
	string getc() const {	return color;	}
	string getn() const {	return name;	}
	void sound() const override final{	cout << "Bark!\n";	}
	void info() const override{	cout << "The " << getc() << " dog's name is " << getn() << endl;	}
};

class smallDog : public Dog {
protected:	
	int size;
public:
	smallDog(string n, string c, int s):Dog(n, c), size(s){}
	~smallDog(){	cout << "~smallDog()\n";	}
	void info() const override final {	cout << "The small " << getc() << " dog's name is " << getn() << endl;	}
};

class bigDog : public Dog{
protected:
	int size;
public:
	bigDog(string n, string c, int s):Dog(n, c), size(s){}
	~bigDog(){	cout << "~bigDog()\n";	}
	void info() const override final {	cout << "The big " << getc() << " dog's name is " << getn() << endl;	}
};
class AnimalList{
private:
    Animal* animalList[10];
    int numAnimal=0;
public:
    ~AnimalList(){
        for(int i=0; i<numAnimal; i++){
            delete animalList[i];
        }
    }
    void addAnimal(Animal* pet){
        animalList[numAnimal++]=pet;
    }
    void sound() const{
        for(int i=0; i<numAnimal; i++){
            animalList[i]->sound();
        }
    }
    void info() const{
        for(int i=0; i<numAnimal; i++){
            animalList[i]->info();
        }        
    }
};
int main(){
    AnimalList aList;
    aList.addAnimal(new Dog("초코","brown"));
    aList.addAnimal(new smallDog("초코","brown",3));
    aList.addAnimal(new bigDog("초코","brown",10));

    aList.sound();
    aList.info();

    return 0;
}