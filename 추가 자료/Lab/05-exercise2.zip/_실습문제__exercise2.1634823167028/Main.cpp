#include <iostream>
using namespace std;
class Angle
{
	public:
		bool isDeg;
		double angle;
		static const double PI;
		void RtoD();
		void DtoR();
		void show();
};
void Angle::RtoD() {
	if(isDeg == 0) {
		angle = angle*180/(Angle::PI);
		isDeg = 1;
	}
}
void Angle::DtoR() {
	if(isDeg == 1){
		angle = angle*(Angle::PI)/180;
		isDeg = 0;
	}
}
void Angle::show() {
	if(isDeg == 1)	cout << angle << "°" << endl;
	else	cout << angle << "rad" << endl;
}

//	°
const double Angle::PI = 3.141592;
int main(){
		bool select; //0(false) 1(true)
		double deg;
		cout << "Enter isdeg and angle: ";
		cin >> select >> deg;
    Angle angle = {select,deg};
    angle.show();
    angle.DtoR();
    angle.show();
    angle.RtoD();
    angle.show();
    return 0;
}