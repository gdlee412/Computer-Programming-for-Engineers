#include <iostream>
#include <string>
using namespace std;

class Animal{
private:
	string name;
	int age;
public:
	static int th;
	Animal(string n, int a){	
		name = n;	age = a; 
		cout << Animal::th << "th Animal()\n";
	}
	virtual void Show(){	cout << "name is " << name << " and age is " << age << endl;	}
	string getName()	{	return name;	}
	int getAge()	{	return age;	}
	virtual ~Animal(){
		cout << Animal::th << "th ~Animal()\n";
	}
};
int Animal::th = 1;

class Dog : public Animal{
private:
public:
	Dog(string n, int a): Animal(n, a){
		cout << Animal::th << "th Dog()\n";	th++;
	}
	void Show(){	cout << "name is " << getName() << " and age is " << getAge() << endl;	}
	virtual ~Dog(){
		th--;
		cout << Animal::th << "th ~Dog()\n";
	}
};
int main(){
  Animal* animals[2];
	animals[0] = new Dog("초코",10);
	animals[1] = new Dog("쿠키",6);
  animals[0]->Show();
  animals[1]->Show();

  delete animals[1];
  delete animals[0];

	return 0;
}