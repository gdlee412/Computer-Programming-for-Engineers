#include <iostream>
#include <string>
using namespace std;

class Player{
private:
	string name;
public:
	Player(string n):	name(n){}
	string getname(){	return name;	}
};
class MainPlayer : public Player{
private:
	int salary;
public:
	MainPlayer(string n, int s):	Player(n),salary(s){}
	int getsalary() {	return salary;	}
	void showinfo(){	cout << getname() << "'s salary: " << getsalary() << endl;	}
};
class SubPlayer : public Player{
private:
	int matches;
	int pay_per_match;
public:
	SubPlayer(string n, int m, int p):	Player(n),matches(m),pay_per_match(p){}
	int getsalary(){	return matches*pay_per_match;	}
	void addmatch(int n){	matches += n;	}
	void showinfo(){	cout << getname() << "'s salary: " << getsalary() << endl;	}
};
class StarPlayer: public MainPlayer{
private:
	int matches;
	int pay_per_match;
public:
	StarPlayer(string n,int s,int m,int p):
	MainPlayer(n,s),matches(m),pay_per_match(p){}
	void addmatch(int n){	matches += n;	}
	int getsalary(){	return MainPlayer::getsalary()+matches*pay_per_match;	}
	void showinfo(){	cout << getname() << "'s salary: " << getsalary() << endl;	}
};

struct node{
	MainPlayer* main;
	SubPlayer* sub;
	StarPlayer* star;
	int type;
};
class PlayerList{
private:
	node list[5];
public:
	int cnt = 0;
	void addplayer(MainPlayer *m){
		list[cnt].main = m;
		list[cnt].type = 0;
		cnt++;
	}
	void addplayer(SubPlayer *s){
		list[cnt].sub = s;
		list[cnt].type = 1;
		cnt++;
	}
	void addplayer(StarPlayer *sp){
		list[cnt].star = sp;
		list[cnt].type = 2;
		cnt++;
	}
	void showinfo(){
		for(int i=0; i<cnt; i++) {
			if(list[i].type == 0) cout << list[i].main->getname() << "'s salary: "<< list[i].main->getsalary() << endl;
			else if(list[i].type == 1) cout << list[i].sub->getname() << "'s salary: " << list[i].sub->getsalary() << endl;
			else if(list[i].type == 2) cout << list[i].star->getname() << "'s salary: " << list[i].star->getsalary() << endl;
		}
	}
	void showtotal(){
		int total = 0;
		for(int i=0; i<cnt; i++) {
			if(list[i].type == 0) total += list[i].main->getsalary();
			else if(list[i].type == 1) total += list[i].sub->getsalary();
			else if(list[i].type == 2) total += list[i].star->getsalary();
		}
		cout << "Total Salary: " << total << endl;
	}
};
int main(){
    PlayerList players;
    players.addplayer(new MainPlayer("태훈",200));
    players.addplayer(new MainPlayer("준희",300));

    SubPlayer* b = new SubPlayer("충원",15,5);
    b->addmatch(5);
    players.addplayer(b);

    StarPlayer* c = new StarPlayer("두영",500,30,10);
    c->addmatch(10);
    players.addplayer(c);

    players.showinfo();
    players.showtotal();

    return 0;
}