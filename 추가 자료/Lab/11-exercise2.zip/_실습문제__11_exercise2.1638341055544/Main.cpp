#include <iostream>
#include <map>
using namespace std;
class Student
{
public:
	Student() {}
	Student(string name, string math_grade, string programming_grade);
	float get_GPA();
	void show();

	string name;	
	string math_grade;
	string programming_grade;
	static map<string, float> grade_policy;
};
Student::Student(string name, string math_grade, 
		string programming_grade) {
	this->name = name;
	this->math_grade = math_grade;
	this->programming_grade = programming_grade;
}
map<string, float> Student::grade_policy = {{ "A+",4.5f },{ "A",4.0f },
		{ "B+",3.5f }, { "B",3.0f }, { "C+",2.5f }, { "C",2.0f },
		{ "D+",1.5f }, { "D",1.0f }, { "F",0.0f } };

void Student::show() { cout << name <<"(GPA:";
	cout.precision(2);
	cout << get_GPA()<<") ";}
float Student::get_GPA() {
	map<string, float>::iterator i1 = grade_policy.find(math_grade);
	map<string, float>::iterator i2 = grade_policy.find(programming_grade);
	float gpa = (i1->second * 3 + i2->second * 2)/5;
	return gpa;
}

int main() {
	map<string, Student> stm;
	string n, m, p, crt;
	
	while(true) {
    cout<<"Input add or del or show or exit: ";
		cin >> crt;
		if (crt == "add") {
			cout << "Input name, grades: ";
			cin >> n >> m >> p;
			Student tmp(n, m, p);
			stm.insert(pair<string, Student>(n, tmp));
			cout << n << " inserted\n";
		}
    else if (crt == "del") {
			cout << "Input name: ";
			cin >> n;
			stm.erase(n);
			cout << n << " deleted\n";
		}
    else if (crt == "show") {
			for (auto x : stm) x.second.show();
			cout << endl;
    }
		else if (crt == "exit") {	break;	}
  }
	return 0;
}