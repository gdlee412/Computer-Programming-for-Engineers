#include <iostream>
#include <string>
using namespace std;

class person{
private:
	string name;
	int	age;
	bool adult;
public:
	person( string, int, bool );
	person( string, int );
  string getName();
  bool isAdult();
};
person::person(string a, int b, bool c){
	name = a; age = b; adult = c;
}
person::person(string a, int b) : person(a, b, 0)
{ }

bool person::isAdult(){
	if(adult == true)	return true;
	else	return false;
}

string person::getName(){
	return name;
}
int main()
{
	person a( "Tom", 35, true );
	person b( "Daniel", 17 );
    
	string result;
	char adult[] = " is adult.";
	char kid[]	 = " is not adult.";
	result = a.isAdult() ? adult : kid; 
	cout<<a.getName()<<result<<endl;
	result = b.isAdult() ? adult : kid; 
	cout<<b.getName()<<result<<endl;

	return 0;
}