#include <iostream>
#include <vector>
using namespace std;

int main()
{
	int a=0, d;
	vector<int> v1;
	while(1){
		cout << "Input Number: ";
		cin >> a;
		if(a == -1)	break;
		v1.push_back(a);
	}
	vector<int>::iterator s = v1.begin();
	vector<int>::reverse_iterator e;
	cout << "select directon: ";
	cin >> d;
	if(d == 0){
		for(s; s!=v1.end(); s++)
			cout << *s << " ";
		cout << "\n";
	} else {
		for(e=v1.rbegin(); e!=v1.rend(); e++)
			cout << *e << " ";
		cout << "\n";
	}
}