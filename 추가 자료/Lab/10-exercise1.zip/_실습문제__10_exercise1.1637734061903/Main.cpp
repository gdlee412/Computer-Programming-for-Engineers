#include <iostream>
using namespace std;
class Point{
private:
	int xpos, ypos;
public:
	Point(int x, int y):xpos(x),ypos(y){}
	void show() const {	cout << "(" << xpos << "," << ypos << ")\n";	}
	int getX() const {	return xpos;	}
	int getY() const {	return ypos;	}
};
const Point operator-(int num, const Point &ref){
	const Point pos(num-ref.getX(), num-ref.getY());
	return pos;
}
const Point operator-(const Point &ref){
	const Point pos(-ref.getX(), -ref.getY());
	return pos;
}
const Point operator -(const Point &ref1, const Point &ref2){
	const Point pos(ref1.getX()-ref2.getX(), ref1.getY()-ref2.getY());
	return pos;
}
int main(){
    Point pos1(3,4);
    Point pos2(10,20);
    Point pos3=pos2-pos1;
    Point pos4=20-pos3;
    Point pos5=-pos4;
    
    pos3.show();
    pos4.show();
    pos5.show();
    return 0;
}