#include <iostream>
#include <string>

using namespace std;

struct Student{
		int ID;
		string name;
		string major;
};

void show(Student a){
	cout << "ID: " << a.ID << endl;
	cout << "Name: " << a.name << endl;
	cout << "Major: " << a.major;
}
int main(){
    Student student = {2021711919,"Taehun","Artificial Intelligence"};
    show(student);
}