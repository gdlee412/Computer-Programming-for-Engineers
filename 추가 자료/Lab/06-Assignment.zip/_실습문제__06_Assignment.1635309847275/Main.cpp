#include <iostream>
#include <string>
using namespace std;

class person{
private:
	string name;
	int	age;
	bool adult;
public:
	person( string, int );
  string getName();
  bool isAdult();
};
person::person(string a, int b){
	name = a;	age = b;
	if(b >= 20)	adult = true;
	else	adult = false;
}
bool person::isAdult(){
	if(adult == true)	return true;
	else	return false;
}
string person::getName(){	return name; }
class company{
private:
	string	name;
	static bool operating;
	int numCustomer = 0;
public:
	company( string );
	void showNumCustomer() const;
	static void offOperating();
	static bool isOperating();
	void signUp( person );
};
bool company::operating = 1;
company::company(string a){
	name = a;	operating = 1;	numCustomer = 0;
}
void company::showNumCustomer() const{
	cout << "Number of VIP membership : " << numCustomer << endl;
}
void company::offOperating(){	operating = 0;	}
bool company::isOperating(){	return operating;	}
void company::signUp(person a){
	this->name = a.getName();
	if(a.isAdult() == true){
		(this->numCustomer)++;
		cout << "Signed up.\n";
	} else {
		cout << a.getName() << " is not adult. Can not sign up.\n";
	}
}
int main()
{
	company a( "cacao" );
	while( company::isOperating() )
	{
		cout<<"Enter your name and age."<<endl;
		string name; int age;
		cin>>name>>age;	
		person customer( name,age );
		a.signUp( customer );
		a.showNumCustomer();

		cout<<"Is it still operating tile?"<<endl;
		char ans; cin>>ans;
		if( ans=='n'||ans=='N')	
			company::offOperating();
		cout<<endl;
	}
	cout<<"Operating hours are over."<<endl;
	return 0;
}