#include <iostream>
#include <string>
using namespace std;
class Animal{
protected:
    string name;
public:
    Animal(string myname):name(myname){}
    virtual ~Animal(){}
    virtual void sound() const=0;
    virtual void info() const=0;
};
class Dog : public Animal {
private:
	string color;
public:
	Dog(string n, string c):Animal(n), color(c){}
	~Dog(){	cout << "~Dog()\n";	}
	string getc() const {	return color;	}
	string getn() const {	return name;	}
	void sound() const override final{	cout << "Bark!\n";	}
	void info() const override{	cout << "The " << getc() << " dog's name is " << getn() << endl;	}
	void only_dog(){	cout << "dogs\n";	}
};

class Cat : public Animal {
private:
	string color;
public:
	Cat(string n, string c):Animal(n), color(c){}
	~Cat(){	cout << "~Cat()\n";	}
	string getc() const {	return color;	}
	string getn() const {	return name;	}
	void sound() const override final{	cout << "Bark!\n";	}
	void info() const override{	cout << "The " << getc() << " cat's name is " << getn() << endl;	}
	void only_cat(){	cout << "cats\n";	}
};

class smallDog : public Dog {
protected:	
	int size;
public:
	smallDog(string n, string c, int s):Dog(n, c), size(s){}
	~smallDog(){	cout << "~smallDog()\n";	}
	void info() const override final {	cout << "The small " << getc() << " dog's name is " << getn() << endl;	}
};

class bigDog : public Dog{
protected:
	int size;
public:
	bigDog(string n, string c, int s):Dog(n, c), size(s){}
	~bigDog(){	cout << "~bigDog()\n";	}
	void info() const override final {	cout << "The big " << getc() << " dog's name is " << getn() << endl;	}
};

class AnimalList{
private:
	Animal* animalList[10];
	int numAnimal=0;
public:
	~AnimalList(){	for(int i=0; i<numAnimal; i++){	delete animalList[i];}	}
	void addAnimal(Animal* pet){	animalList[numAnimal++]=pet;	}
	void all_animal(){
		Cat* cat; Dog* dog; smallDog* sdog; bigDog* bdog;
		for(int i=0; i<numAnimal; i++){
			if(cat = dynamic_cast<Cat*>(animalList[i])) {
				cat->only_cat();
				cat->info();
			}
			else if(dog = dynamic_cast<Dog*>(animalList[i])) {
				if(sdog = dynamic_cast<smallDog*>(animalList[i]))	{
					sdog->only_dog();	sdog->info();
				}
				else if(bdog = dynamic_cast<bigDog*>(animalList[i])) {
					bdog->only_dog();	bdog->info();
				}
				else {	dog->only_dog();	dog->info();	}
			}
		}
	}
};
int main(){
    AnimalList aList;
    aList.addAnimal(new Dog("초코","brown"));
    aList.addAnimal(new Cat("하양","white"));
    aList.addAnimal(new smallDog("초코","brown",3));
    aList.addAnimal(new bigDog("초코","brown",10));

    aList.all_animal();

    return 0;
}