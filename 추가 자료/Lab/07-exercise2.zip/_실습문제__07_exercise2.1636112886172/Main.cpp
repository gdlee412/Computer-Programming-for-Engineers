#include <iostream>
#include <string>
using namespace std;

class Player{
private:
    string name;
public:
	Player(string myname):
	name(myname){}
	string getname() {	return name;	}
};
class MainPlayer : public Player{
private:
    int salary;
public:
	MainPlayer(string myname, int mysalary):
	Player(myname), salary(mysalary){}
	void showinfo(){
		cout << getname() << "'s salary: " << salary << endl;
	}
};
class SubPlayer : public Player{
private:
    int matches;
    int pay_per_match;
public:
	SubPlayer(string myname, int mymatch, int mypay):
	Player(myname), matches(mymatch), pay_per_match(mypay){}
	void showinfo(){
		cout << getname() << "'s salary: " << matches*pay_per_match << endl;
	}
	void addmatch(int a){
		matches += a;
	}
};
int main(){
    MainPlayer a("태훈", 200);
    a.showinfo();

    SubPlayer b("충원",15,5);
    b.showinfo();
    b.addmatch(5);
    b.showinfo();

    return 0;
}